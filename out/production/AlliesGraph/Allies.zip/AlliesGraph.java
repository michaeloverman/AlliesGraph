import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Michael on 9/16/2016.
 */
public class AlliesGraph {
    HashMap<Integer, State> states;
    HashMap<Integer, Dispute> disputes;
    HashMap<String, Integer> abbrevs;
    HashMap<Integer, Graph> stateEgonets;

    public AlliesGraph() {
        states = new HashMap<Integer, State>();
        disputes = new HashMap<Integer, Dispute>();
        abbrevs = new HashMap<String, Integer>();
    }
    public void addDispute(Dispute disp) {
        disputes.put(disp.getId(), disp);
    }
    public Dispute getDispute(int id) {
        return disputes.get(id);
    }
    public boolean containsDispute(int id) {
        return disputes.containsKey(id);
    }
    public void addState(State s) {
        states.put(s.getCode(), s);
        abbrevs.put(s.getAbbrev(), s.getCode());
    }
    public int getStateCount() {
        return states.size();
    }
    public List<State> getStates() {
        ArrayList<State> list = new ArrayList<>();
        for (State s : states.values()) {
            list.add(s);
        }
        return list;
    }
    public void disputesToEdges() {
        for (Dispute d : disputes.values()) {
//            System.out.println(d.toString());
            if (d.sideA().size() > 1) {
                for (int i = 0; i < d.sideA().size() - 1; i++) {
//                    System.out.print("outer loop " + i + ": ");
                    for (int j = i + 1; j < d.sideA().size(); j++) {
//                        System.out.println(d.getId() + " " + i + " " + j);
                        String sa = d.sideA().get(i);
                        String sb = d.sideA().get(j);
                        int a = abbrevs.get(sa);
                        int b = abbrevs.get(sb);
                        State one = states.get(a);
                        State two = states.get(b);
                        one.addAlly(two.getCode());
                        two.addAlly(one.getCode());
                    }
//                    System.out.println("");
                }
            }
            if (d.sideB().size() > 1) {
                for (int i = 0; i < d.sideB().size() - 1; i++) {
//                    System.out.print("outer loop " + i + ": ");
                    for (int j = i + 1; j < d.sideB().size(); j++) {
//                        System.out.println(d.getId() + " " + i + " " + j);
                        String sa = d.sideB().get(i);
                        String sb = d.sideB().get(j);
                        int a = abbrevs.get(sa);
                        int b = abbrevs.get(sb);
                        State one = states.get(a);
                        State two = states.get(b);
                        one.addAlly(two.getCode());
                        two.addAlly(one.getCode());
                    }
//                    System.out.println("");
                }
            }

    //        System.out.println(" : " + d.sideA().toString());
        }

    }

    public void findAllies() {
        stateEgonets = new HashMap<>();
        for (State s : states.values()) {
            stateEgonets.put(s.getCode(), alliesEgoNet(s));
            s.setEgonetSize(stateEgonets.get(s.getCode()).getNumVertices());
        }
//        for (int i : stateEgonets.keySet()) {
//            System.out.println("State: " + states.get(i).getName() + " Egonet Size: " +
//                    stateEgonets.get(i).getNumVertices());
//        }

    }
    public void egonetsBySize() {
        egonetsBySize(1000);
    }
    public void egonetsBySize(int howMany) {
        if (stateEgonets == null) return;
        ArrayList<State> tempStates = new ArrayList<>();
        tempStates.addAll(states.values());
        int i = 0;
        while (!tempStates.isEmpty()) {
            if (i++ > howMany) break;
            int max = -1;
            State biggestNet = null;
            for (State s : tempStates) {
                if (s.getEgonetSize() > max) {
                    biggestNet = s;
                    max = s.getEgonetSize();
                }
            }
            System.out.println(biggestNet.getName() + ": " + biggestNet.getEgonetSize());
            tempStates.remove(biggestNet);
        }
    }
    public Graph alliesEgoNet(State state) {
        Graph egonet = new Graph();
        if (!states.containsValue(state)) return egonet;
        egonet.addVertex(state.getCode());
        for(int i : state.getAllies()) {
            egonet.addVertex(i);
            egonet.addEdge(state.getCode(), i);
        }
        for (int i : egonet.getVertices()) {
            for (int j : states.get(i).getAllies()) {
                egonet.addEdge(i, j);  // addEdge method does not add the edge, if the neighbor is not already in the egonet
            }
        }

        return egonet;
    }
    public static void main(String[] args) {
        AlliesGraph graph = new AlliesGraph();
        Parser.parseStateCodes(graph);
        System.out.println(graph.getStateCount() + " states in graph");
//        for (State s : graph.getStates()) {
//            System.out.println(s.toString());
//        }
        Parser.parseDisputes(graph);
        graph.disputesToEdges();
        System.out.println(graph.disputes.size() + " disputes");
//        for (State s : graph.getStates()) {
//            System.out.print(s.alliesToString());
//
//        }
        graph.findAllies();
        graph.egonetsBySize();
    }
}
